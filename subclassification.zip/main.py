a=2
b=5

print (a+b)

for i in range(1,90,44):
 print("lol")

  
 
